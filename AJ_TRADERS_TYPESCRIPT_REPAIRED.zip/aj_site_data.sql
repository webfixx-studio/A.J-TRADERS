-- A.J TRADERS — PRODUCTION SECURITY / GLOBAL SYNC SQL
--
-- IMPORTANT:
-- 1) Create ONE Supabase Auth user with email: ajtraders01052026@gmail.com
--    (Authentication -> Users -> Add user).
-- 2) Use that account in admin.html. The browser's public anon key is NOT an admin secret.
-- 3) This script intentionally preserves existing aj_site_data / aj_leads rows.
-- 4) Public visitors can READ public site data and INSERT inquiries only.
--    Only the authenticated admin email above can write site content or manage leads/media.

create table if not exists public.aj_site_data (
  id text primary key,
  payload jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now()
);

alter table public.aj_site_data enable row level security;

revoke all on table public.aj_site_data from anon, authenticated;
grant select on table public.aj_site_data to anon, authenticated;
grant insert, update on table public.aj_site_data to authenticated;

drop policy if exists "A J TRADERS public read" on public.aj_site_data;
drop policy if exists "A J TRADERS admin write" on public.aj_site_data;
drop policy if exists "A J TRADERS admin update" on public.aj_site_data;

-- Public pages are READ ONLY.
create policy "A J TRADERS public read"
on public.aj_site_data for select
to anon, authenticated
using (true);

-- Only the designated Supabase Auth account can create/update the main content row.
create policy "A J TRADERS admin write"
on public.aj_site_data for insert
to authenticated
with check ((auth.jwt() ->> 'email') = 'ajtraders01052026@gmail.com');

create policy "A J TRADERS admin update"
on public.aj_site_data for update
to authenticated
using ((auth.jwt() ->> 'email') = 'ajtraders01052026@gmail.com')
with check ((auth.jwt() ->> 'email') = 'ajtraders01052026@gmail.com');

-- -----------------------------------------------------------------------------
-- LEADS / CUSTOMER INQUIRIES
-- -----------------------------------------------------------------------------
create table if not exists public.aj_leads (
  id bigint primary key,
  name text,
  mobile text,
  email text,
  message text,
  date text,
  source text,
  created_at timestamptz not null default now()
);

alter table public.aj_leads enable row level security;

revoke all on table public.aj_leads from anon, authenticated;
grant insert on table public.aj_leads to anon, authenticated;
grant select, delete on table public.aj_leads to authenticated;

drop policy if exists "A J TRADERS leads insert" on public.aj_leads;
drop policy if exists "A J TRADERS leads read" on public.aj_leads;
drop policy if exists "A J TRADERS leads delete" on public.aj_leads;

create policy "A J TRADERS leads insert"
on public.aj_leads for insert
to anon, authenticated
with check (
  char_length(coalesce(name,'')) <= 150 and
  char_length(coalesce(mobile,'')) <= 40 and
  char_length(coalesce(email,'')) <= 254 and
  char_length(coalesce(message,'')) <= 5000
);

create policy "A J TRADERS leads read"
on public.aj_leads for select
to authenticated
using ((auth.jwt() ->> 'email') = 'ajtraders01052026@gmail.com');

create policy "A J TRADERS leads delete"
on public.aj_leads for delete
to authenticated
using ((auth.jwt() ->> 'email') = 'ajtraders01052026@gmail.com');

-- -----------------------------------------------------------------------------
-- SUPABASE STORAGE
-- -----------------------------------------------------------------------------
-- Public read is required because public pages use image URLs.
-- Writes/deletes are restricted to the authenticated admin.
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values (
  'aj-traders-media',
  'aj-traders-media',
  true,
  5242880,
  array['image/png','image/jpeg','image/webp','image/gif','image/svg+xml']::text[]
)
on conflict (id) do update set
  public = true,
  file_size_limit = 5242880,
  allowed_mime_types = array['image/png','image/jpeg','image/webp','image/gif','image/svg+xml']::text[];

revoke all on table storage.objects from anon, authenticated;
grant select on table storage.objects to anon, authenticated;
grant insert, update, delete on table storage.objects to authenticated;

drop policy if exists "A J TRADERS media public read" on storage.objects;
drop policy if exists "A J TRADERS media upload" on storage.objects;
drop policy if exists "A J TRADERS media update" on storage.objects;
drop policy if exists "A J TRADERS media delete" on storage.objects;

create policy "A J TRADERS media public read"
on storage.objects for select
to anon, authenticated
using (bucket_id = 'aj-traders-media');

create policy "A J TRADERS media upload"
on storage.objects for insert
to authenticated
with check (
  bucket_id = 'aj-traders-media' and
  (auth.jwt() ->> 'email') = 'ajtraders01052026@gmail.com'
);

create policy "A J TRADERS media update"
on storage.objects for update
to authenticated
using (
  bucket_id = 'aj-traders-media' and
  (auth.jwt() ->> 'email') = 'ajtraders01052026@gmail.com'
)
with check (
  bucket_id = 'aj-traders-media' and
  (auth.jwt() ->> 'email') = 'ajtraders01052026@gmail.com'
);

create policy "A J TRADERS media delete"
on storage.objects for delete
to authenticated
using (
  bucket_id = 'aj-traders-media' and
  (auth.jwt() ->> 'email') = 'ajtraders01052026@gmail.com'
);
