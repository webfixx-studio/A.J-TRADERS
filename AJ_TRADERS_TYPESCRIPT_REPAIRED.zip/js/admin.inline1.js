// TypeScript-converted inline script; DOM/UI behavior intentionally preserved.
// @ts-nocheck
async function login() { var email = (document.getElementById('adminEmail').value || '').trim(); var p = document.getElementById('pass').value || ''; if (!email || !p) {
    alert('Enter admin email and password.');
    return;
} try {
    await AJShared.signIn(email, p);
    await AJShared.pull();
    document.getElementById('loginBox').classList.add('hidden');
    document.getElementById('dashboard').classList.remove('hidden');
    loadAll();
    await loadLeads();
}
catch (e) {
    console.error(e);
    alert('Login failed: ' + e.message);
} }
async function logout() { try {
    await AJShared.signOut();
}
catch (e) { } document.getElementById('dashboard').classList.add('hidden'); document.getElementById('loginBox').classList.remove('hidden'); }
async function tab(i, ev) { document.querySelectorAll('.tab').forEach(function (t) { t.classList.add('hidden'); }); document.getElementById('t' + i).classList.remove('hidden'); document.querySelectorAll('.tabBtn').forEach(function (b) { b.classList.remove('bg-[#D4AF37]', 'text-black'); b.classList.add('bg-slate-900/80', 'text-slate-300'); }); if (ev && ev.currentTarget) {
    ev.currentTarget.classList.add('bg-[#D4AF37]', 'text-black');
    ev.currentTarget.classList.remove('bg-slate-900/80', 'text-slate-300');
} if (i === 0)
    loadLeads(); if (i === 2)
    renderHero(); if (i === 3)
    renderProd(); if (i === 4)
    renderFaqEdit(); if (i === 5)
    renderGalleryEdit(); if (i === 6)
    loadStatsForm(); if (i === 7)
    renderTestimonialEdit(); if (i === 8)
    renderBlogEdit(); if (i === 9)
    renderServicesEdit(); if (i === 10)
    renderCertsEdit(); }
{
    document.querySelectorAll('.tab').forEach(function (t) { t.classList.add('hidden'); });
    document.getElementById('t' + i).classList.remove('hidden');
    document.querySelectorAll('.tabBtn').forEach(function (b) { b.classList.remove('bg-[#D4AF37]', 'text-black'); b.classList.add('bg-slate-800'); });
    event.target.classList.add('bg-[#D4AF37]', 'text-black');
    event.target.classList.remove('bg-slate-800');
    if (i === 2)
        renderHero();
    if (i === 3)
        renderProd();
    if (i === 4)
        renderFaqEdit();
    if (i === 5)
        renderGalleryEdit();
    if (i === 6)
        loadStatsForm();
    if (i === 7)
        renderTestimonialEdit();
    if (i === 8)
        renderBlogEdit();
    if (i === 9)
        renderServicesEdit();
    if (i === 10)
        renderCertsEdit();
}
async function loadLeads() { var el = document.getElementById('leads'); if (!el)
    return; try {
    var leads = await AJShared.getLeads();
    if (!leads.length) {
        el.innerHTML = '<p class="text-[10px] text-slate-500">No leads yet.</p>';
        return;
    }
    leads.forEach(function (l) { l._safe = AJShared.escapeHTML; });
    el.innerHTML = leads.map(function (l) { var esc = AJShared.escapeHTML; var mob = String(l.mobile || '').replace(/[^0-9]/g, ''); return '<div class="admin-section flex flex-col sm:flex-row gap-3 justify-between"><div class="min-w-0"><div class="font-bold text-sm">' + esc(l.name || 'Visitor') + ' <span class="text-slate-500">•</span> ' + esc(l.mobile || '') + '</div><div class="text-[10px] text-slate-400 mt-1">' + esc(l.email || '') + ' • ' + esc(l.date || l.created_at || '') + '</div><div class="text-xs text-slate-300 mt-2 whitespace-pre-wrap">' + esc(l.message || '') + '</div></div><div class="flex sm:flex-col gap-2 shrink-0"><a href="https://wa.me/' + mob + '" target="_blank" class="bg-emerald-600 px-3 py-2 rounded-lg text-[10px] text-center">WhatsApp</a><a href="tel:+91' + mob + '" class="bg-slate-800 px-3 py-2 rounded-lg text-[10px] text-center">Call</a><button onclick="del(' + Number(l.id) + ')" class="bg-red-950/70 border border-red-500/20 px-3 py-2 rounded-lg text-[10px]">Delete</button></div></div>'; }).join('');
}
catch (e) {
    console.error(e);
    el.innerHTML = '<p class="text-xs text-red-300">Unable to load leads: ' + AJShared.escapeHTML(e.message) + '</p>';
} }
async function del(id) { if (!confirm('Delete this inquiry?'))
    return; try {
    await AJShared.deleteLead(id);
    await loadLeads();
}
catch (e) {
    alert('Delete failed: ' + e.message);
} }
async function clearLeads() { if (!confirm('Delete ALL customer inquiries? This cannot be undone.'))
    return; try {
    await AJShared.clearLeads();
    await loadLeads();
    alert('All leads deleted.');
}
catch (e) {
    alert('Clear failed: ' + e.message);
} }
function validImageFile(f) { if (!f)
    return false; if (f.size > 5000000) {
    alert('Image too large - maximum 5MB.');
    return false;
} if (!/^image\/(png|jpeg|webp|gif|svg\+xml)$/i.test(f.type)) {
    alert('Only PNG, JPG, WEBP, GIF or SVG images are allowed.');
    return false;
} return true; }
function localEsc(v) { return String(v == null ? '' : v).replace(/[&<>'"]/g, function (c) { if (c === '&')
    return '&amp;'; if (c === '<')
    return '&lt;'; if (c === '>')
    return '&gt;'; if (c === "'")
    return '&#39;'; return '&quot;'; }); }
function adminEsc(v) { return (window.AJShared && AJShared.escapeHTML) ? AJShared.escapeHTML(v) : localEsc(v); }
function loadContentForm() { var c = JSON.parse(localStorage.getItem('aj_content') || '{}'); var val = function (k, d) { return Object.prototype.hasOwnProperty.call(c, k) ? (c[k] ?? '') : d; }; document.getElementById('fMobile').value = val('mobile', '9999055398'); document.getElementById('fEmail').value = val('email', 'ajtraders01052026@gmail.com'); document.getElementById('fAddress').value = val('address', 'Plot No. 123, Industrial Area, Faridabad, Haryana - 121001'); document.getElementById('fInstagram').value = val('instagram', 'https://instagram.com/'); document.getElementById('fYoutube').value = val('youtubeChannel', 'https://youtube.com/'); document.getElementById('fFacebook').value = val('facebook', 'https://facebook.com/'); document.getElementById('cName').value = val('ceoName', 'JATIN VARMA'); document.getElementById('cBio').value = val('ceoBio', 'Trusted wholesaler since 2015 - We purchase in bulk from factories and supply at wholesale rates PAN India'); document.getElementById('cPhoto').value = c.ceoPhoto && String(c.ceoPhoto).startsWith('data:') ? '' : (c.ceoPhoto || ''); document.getElementById('logoUrl').value = c.logo && String(c.logo).startsWith('data:') ? '' : (c.logo || ''); document.getElementById('whatsappUrl').value = c.whatsappUrl || ''; document.getElementById('ytLink').value = c.youtubeRaw || ''; if (c.youtube)
    document.getElementById('ytPreview').src = c.youtube; }
async function saveContent() { var c = JSON.parse(localStorage.getItem('aj_content') || '{}'); c.mobile = document.getElementById('fMobile').value.trim(); c.email = document.getElementById('fEmail').value.trim(); c.address = document.getElementById('fAddress').value.trim(); c.instagram = document.getElementById('fInstagram').value.trim(); c.youtubeChannel = document.getElementById('fYoutube').value.trim(); c.facebook = document.getElementById('fFacebook').value.trim(); c.ceoName = document.getElementById('cName').value.trim(); c.ceoBio = document.getElementById('cBio').value.trim(); var photo = document.getElementById('cPhoto').value.trim(); if (photo)
    c.ceoPhoto = photo;
else
    delete c.ceoPhoto; var logo = document.getElementById('logoUrl').value.trim(); if (logo)
    c.logo = logo;
else
    delete c.logo; var wa = document.getElementById('whatsappUrl').value.trim(); if (wa)
    c.whatsappUrl = wa;
else
    delete c.whatsappUrl; localStorage.setItem('aj_content', JSON.stringify(c)); var ok = await AJShared.push(); if (ok) {
    alert('Saved successfully. Changes are now global on all devices.');
}
else
    alert('Save failed. Make sure the admin session and Supabase connection are active.'); }
function extractYT(url) { return AJShared.extractYouTubeId(url); }
async function saveYT() { var raw = document.getElementById('ytLink').value.trim(); var id = extractYT(raw); if (!id) {
    alert('Invalid YouTube link - Example: https://www.youtube.com/watch?v=9P5rS3_w3oo');
    return;
} var embed = 'https://www.youtube.com/embed/' + id; var c = JSON.parse(localStorage.getItem('aj_content') || '{}'); c.youtube = embed; c.youtubeRaw = raw; localStorage.setItem('aj_content', JSON.stringify(c)); document.getElementById('ytPreview').src = embed; var ok = window.AJShared && AJShared.push ? await AJShared.push() : false; alert(ok ? 'Video updated globally - Auto embed code generated.' : 'Video saved locally, but Supabase sync failed.'); }
async function changePass() { var np = document.getElementById('newPass').value.trim(); if (!np) {
    alert('Enter a new password');
    return;
} if (np.length < 8) {
    alert('Password must be at least 8 characters.');
    return;
} try {
    await AJShared.updatePassword(np);
    alert('Admin password updated securely.');
    document.getElementById('newPass').value = '';
}
catch (e) {
    console.error(e);
    alert('Password update failed: ' + e.message);
} }
var HERO = [{ k: 'img_hero_home', l: 'Home Hero - index.html hero background' }, { k: 'img_hero_products', l: 'Products Hero - products.html hero background' }, { k: 'img_hero_services', l: 'Services Hero services.html hero background - NEW PAGE' }, { k: 'img_hero_about', l: 'About Hero - about.html hero background' }, { k: 'img_hero_certificates', l: 'Certificates Hero certificates.html hero background - NEW PAGE' }, { k: 'img_hero_contact', l: 'Contact Hero - contact.html hero background' }, { k: 'img_hero_faq', l: 'FAQ Hero - faq.html hero background' }, { k: 'img_hero_gallery', l: 'Gallery Hero - gallery.html hero background' }, { k: 'img_hero_blog', l: 'Blog Hero - blog.html hero background' }, { k: 'img_hero_clients', l: 'Clients Hero - clients.html hero background' }];
var PROD = [{ k: 'img_about', l: 'About Image - About page main image' }, { k: 'img_prod_05', l: 'Product 0.5m - 0.5m small bubble roll' }, { k: 'img_prod_10', l: 'Product 1.0m - 1.0m standard best seller roll' }, { k: 'img_prod_12', l: 'Product 1.2m - 1.2m large bubble roll' }, { k: 'img_prod_15', l: 'Product 1.5m - 1.5m jumbo bubble roll' }, { k: 'img_prod_tape', l: 'Product Tape - BOPP tapes' }];
function renderHero() { var c = JSON.parse(localStorage.getItem('aj_content') || '{}'); document.getElementById('heroGrid').innerHTML = HERO.map(function (s) { var cur = c[s.k] || ''; return '<div class=bg-[#0B1325] border border-slate-800 p-2 rounded-xl><label class=text-[10px] font-bold>' + s.l + '</label><div class="mt-2 h-20 bg-slate-950 rounded overflow-hidden flex items-center justify-center">' + (cur ? '<img src="' + cur + '" class="w-full h-full object-cover">' : '<span class=text-[9px] text-slate-500>No Image - Default warehouse image dikhega</span>') + '</div><input id="url_' + s.k + '" value="' + (cur.startsWith('data:') ? '' : cur) + '" placeholder="Image URL - https://..." class="w-full mt-2 bg-slate-950 border border-slate-700 p-1 rounded text-[10px]"><input type="file" accept="image/*" onchange="up(this,\'' + s.k + '\')" class="w-full mt-1 text-[8px]"><div class="flex gap-1 mt-1"><button onclick="saveUrl(\'' + s.k + '\')" class="flex-1 bg-[#D4AF37] text-black text-[9px] font-bold py-1 rounded">Save URL</button><button onclick="clearImg(\'' + s.k + '\')" class="bg-red-900 text-[8px] px-2 py-1 rounded">Clear - Default Pe Wapas</button></div></div>'; }).join(''); }
function renderProd() { var c = JSON.parse(localStorage.getItem('aj_content') || '{}'); document.getElementById('prodGrid').innerHTML = PROD.map(function (s) { var cur = c[s.k] || ''; return '<div class=bg-[#0B1325] border border-slate-800 p-2 rounded-xl><label class=text-[10px] font-bold>' + s.l + '</label><div class="mt-1 h-20 bg-slate-950 rounded overflow-hidden flex items-center justify-center">' + (cur ? '<img src="' + cur + '" class="w-full h-full object-cover">' : 'No Image - Default product image') + '</div><input id="url_' + s.k + '" value="' + (cur.startsWith('data:') ? '' : cur) + '" placeholder="Image URL" class="w-full mt-1 bg-slate-950 border border-slate-700 p-1 rounded text-[10px]"><input type="file" accept="image/*" onchange="up(this,\'' + s.k + '\')" class="w-full mt-1 text-[8px]"><div class="flex gap-1 mt-1"><button onclick="saveUrl(\'' + s.k + '\')" class="flex-1 bg-[#D4AF37] text-black text-[9px] font-bold py-1 rounded">Save</button><button onclick="clearImg(\'' + s.k + '\')" class="bg-red-900 text-[8px] px-2 py-1 rounded">Clear</button></div></div>'; }).join(''); }
async function saveUrl(k) { var u = document.getElementById('url_' + k).value.trim(); if (!u) {
    alert('Enter Image URL');
    return;
} var c = JSON.parse(localStorage.getItem('aj_content') || '{}'); c[k] = u; localStorage.setItem('aj_content', JSON.stringify(c)); renderHero(); renderProd(); var ok = window.AJShared && AJShared.push ? await AJShared.push() : false; alert(ok ? 'Updated globally - ' + k : 'Saved locally but global sync failed - ' + k); }
async function up(inp, k) { var f = inp.files && inp.files[0]; if (!f)
    return; if (!validImageFile(f))
    return; if (!window.AJShared || !AJShared.uploadDataUrl) {
    alert('Image service not ready. Please wait 2 seconds and try again.');
    return;
} var r = new FileReader(); r.onload = async function (e) { try {
    var url = await AJShared.uploadDataUrl(e.target.result);
    var c = JSON.parse(localStorage.getItem('aj_content') || '{}');
    c[k] = url;
    localStorage.setItem('aj_content', JSON.stringify(c));
    await AJShared.push();
    renderHero();
    renderProd();
    alert('Uploaded globally - ' + k);
}
catch (err) {
    console.error(err);
    alert('Image upload failed. Please check Supabase Storage/SQL.');
} }; r.readAsDataURL(f); }
function clearImg(k) { if (!confirm('Clear image? Default image pe wapas jayega - Confirm?'))
    return; var c = JSON.parse(localStorage.getItem('aj_content') || '{}'); delete c[k]; localStorage.setItem('aj_content', JSON.stringify(c)); renderHero(); renderProd(); alert('Cleared - Default image dikhega'); }
function getDefaultFaqs() { return [{ q: "Are you a factory or a wholesaler?", a: "We are a B2B wholesaler based in Faridabad, Haryana. We purchase bubble wrap rolls in bulk directly from leading factories (10,000+ rolls at a time), maintain ready stock in our Faridabad warehouse, and supply to businesses across India at genuine wholesale prices. No factory MOQ (50-100 rolls) and no waiting time (3-5 days). Our MOQ is just 1 roll, dispatch same day." }, { q: "What is your minimum order quantity (MOQ)?", a: "From 1 roll to 1000+ rolls. Low MOQ from 1 roll. We are a wholesaler, not a factory, so we can supply from 1 roll to bulk 1000+ rolls at wholesale rates. Best for small businesses, e-commerce sellers, Amazon, Flipkart sellers who need low MOQ." }, { q: "What is your delivery time? Same day dispatch?", a: "Same day dispatch from Faridabad godown if order before 2 PM. Courier delivery 1-3 days for small orders (1-20 rolls), transport delivery 2-5 days for bulk orders (20+ rolls) PAN India. We supply to 5000+ B2B clients across Delhi, Gurgaon, Noida, Mumbai, Bangalore, Hyderabad, Chennai, Pune, Kolkata." }, { q: "Do you provide GST invoice for all orders?", a: "Yes, 100% GST invoice for all orders. We are a registered GST wholesaler with GSTIN. Proper GST invoice for your business accounting. MSME registered wholesaler." }, { q: "What is the quality of your bubble wrap rolls? GSM checked?", a: "Best quality bubble wrap rolls - Each roll checked for GSM (40 GSM to 120 GSM), width (0.5m to 1.5m), length (100m), bubble quality (small bubble 10mm & large bubble 20mm) before warehousing in Faridabad godown. Only 0.5% return rate due to strict quality checking. Replacement guarantee for any manufacturing defect within 7 days." }, { q: "What are your wholesale rates? How to get best rate?", a: "We give genuine wholesale rates because we buy in huge bulk from factories (10,000+ rolls at a time). Best rates guaranteed for B2B clients. To get best rate, tell us your requirement - Size (0.5m to 1.5m), GSM (40-120 GSM), Quantity (1 roll to 1000+ rolls), Delivery location. We give rate within 30 minutes via WhatsApp. Call +91 9999055398 for instant rate." }, { q: "Why should I buy from wholesaler like you instead of factory?", a: "Factories have high MOQ 50-100 rolls and waiting time 3-5 days for manufacturing. Wholesaler like A.J TRADERS gives you from 1 roll, same day dispatch, PAN India delivery in 1-3 days, GST invoice, quality checked, replacement guarantee, and best wholesale rates. 5000+ B2B clients trust us for same day dispatch and low MOQ." }]; }
var currentFaqs = [];
function renderFaqEdit() { var s = localStorage.getItem('aj_faqs'); currentFaqs = s ? JSON.parse(s) : getDefaultFaqs(); document.getElementById('faqEditList').innerHTML = currentFaqs.map(function (it, i) { return '<div class="bg-[#0B1325] border border-slate-800 p-2 rounded-xl"><div class="flex justify-between items-center"><span class="text-[10px] font-bold text-[#D4AF37]">FAQ ' + (i + 1) + ' - Question + Answer Editable</span><button onclick="deleteFaq(' + i + ')" class="bg-red-900 text-[9px] px-2 py-1 rounded">Delete FAQ</button></div><label class="text-[9px] text-slate-400 mt-2 block">Question:</label><input id="faq_q_' + i + '" value="' + adminEsc(it.q) + '" class="w-full mt-1 bg-slate-950 border border-slate-700 p-1 rounded text-xs"><label class="text-[9px] text-slate-400 mt-2 block">Answer:</label><textarea id="faq_a_' + i + '" rows="3" class="w-full mt-1 bg-slate-950 border border-slate-700 p-1 rounded text-xs">' + adminEsc(it.a) + '</textarea></div>'; }).join(''); }
function addFaq() { currentFaqs.push({ q: "New Question - Enter your question here", a: "New Answer - Enter your detailed answer here - Fully editable from admin panel" }); renderFaqEdit(); saveFaqs(false); }
function deleteFaq(i) { if (!confirm('Delete this FAQ?'))
    return; currentFaqs.splice(i, 1); renderFaqEdit(); saveFaqs(false); }
function saveFaqs(show = true) { var upd = []; for (var i = 0; i < currentFaqs.length; i++) {
    var q = document.getElementById('faq_q_' + i);
    var a = document.getElementById('faq_a_' + i);
    if (q && a && q.value.trim() && a.value.trim())
        upd.push({ q: q.value.trim(), a: a.value.trim() });
} currentFaqs = upd; localStorage.setItem('aj_faqs', JSON.stringify(currentFaqs)); if (show)
    alert('FAQs Saved - ' + currentFaqs.length + ' FAQs - FAQ page + all pages update'); renderFaqEdit(); }
function resetFaqs() { if (!confirm('Reset to default 7 FAQs? Your custom FAQs delete ho jayenge - Confirm?'))
    return; localStorage.removeItem('aj_faqs'); renderFaqEdit(); alert('Reset to default 7 FAQs'); }
function getDefaultGallery() { return [{ title: "Warehouse - Ready Stock - Faridabad Godown", img: "https://images.unsplash.com/photo-1586528116311-ad8dd3c8310d?w=600&q=80" }, { title: "Bubble Wrap Rolls 1.0m - Best Seller - Ready Stock", img: "https://images.unsplash.com/photo-1553413077-190dd305871c?w=600&q=80" }, { title: "Bulk Dispatch - Same Day Dispatch - PAN India Delivery", img: "https://images.unsplash.com/photo-1605745341112-85968b19335b?w=600&q=80" }]; }
var currentGallery = [];
function renderGalleryEdit() { var s = localStorage.getItem('aj_gallery'); currentGallery = s ? JSON.parse(s) : getDefaultGallery(); document.getElementById('galleryEditGrid').innerHTML = currentGallery.map(function (it, i) { return '<div class="bg-[#0B1325] border border-slate-800 p-2 rounded-xl"><div class="h-20 bg-slate-950 rounded overflow-hidden mb-1">' + (it.img ? '<img src="' + it.img + '" class="w-full h-full object-cover">' : 'No Image') + '</div><label class="text-[9px] text-slate-400">Title:</label><input id="gal_title_' + i + '" value="' + it.title.replace(/"/g, '&quot;') + '" class="w-full bg-slate-950 border border-slate-700 p-1 rounded text-[10px] mb-1"><label class="text-[9px] text-slate-400">Image URL:</label><input id="gal_url_' + i + '" value="' + (it.img.startsWith('data:') ? '' : it.img) + '" placeholder="https://..." class="w-full bg-slate-950 border border-slate-700 p-1 rounded text-[10px] mb-1"><input type="file" accept="image/*" onchange="upGal(this,' + i + ')" class="w-full text-[8px] mb-1"><div class="flex gap-1"><button onclick="saveGalItem(' + i + ')" class="flex-1 bg-[#D4AF37] text-black text-[9px] py-1 rounded font-bold">Save</button><button onclick="delGal(' + i + ')" class="bg-red-900 text-[9px] px-2 py-1 rounded">Delete</button></div></div>'; }).join(''); }
function addGallery() { currentGallery.push({ title: "New Gallery Image - Enter title", img: "" }); renderGalleryEdit(); saveGallery(false); }
function delGal(i) { if (!confirm('Delete this gallery image?'))
    return; currentGallery.splice(i, 1); renderGalleryEdit(); saveGallery(false); }
async function upGal(inp, i) { var f = inp.files && inp.files[0]; if (!f)
    return; if (!validImageFile(f))
    return; var r = new FileReader(); r.onload = async function (e) { try {
    currentGallery[i].img = await AJShared.uploadDataUrl(e.target.result);
    renderGalleryEdit();
    saveGallery(false);
    await AJShared.push();
}
catch (err) {
    console.error(err);
    alert('Gallery image upload failed.');
} }; r.readAsDataURL(f); }
function saveGalItem(i) { var t = document.getElementById('gal_title_' + i); var u = document.getElementById('gal_url_' + i); if (t)
    currentGallery[i].title = t.value.trim() || 'Gallery Image'; if (u && u.value.trim())
    currentGallery[i].img = u.value.trim(); saveGallery(false); }
function saveGallery(show = true) { var upd = []; for (var i = 0; i < currentGallery.length; i++) {
    var t = document.getElementById('gal_title_' + i);
    var u = document.getElementById('gal_url_' + i);
    var title = t ? t.value.trim() : currentGallery[i].title;
    var img = currentGallery[i].img;
    if (u && u.value.trim())
        img = u.value.trim();
    if (title || img)
        upd.push({ title: title, img: img });
} currentGallery = upd; localStorage.setItem('aj_gallery', JSON.stringify(currentGallery)); if (show)
    alert('Gallery Saved - ' + currentGallery.length + ' images - Gallery page update'); renderGalleryEdit(); }
function clearGallery() { if (confirm('Clear all gallery images? Confirm?')) {
    localStorage.removeItem('aj_gallery');
    renderGalleryEdit();
} }
function getDefaultStats() { return { s1_num: "5000+", s1_label: "B2B Clients", s2_num: "24-48 Hours", s2_label: "Delivery Time", s3_num: "10+ Years", s3_label: "Experience", s4_num: "Same Day", s4_label: "Dispatch", s5_num: "PAN India", s5_label: "Delivery", s6_num: "100%", s6_label: "GST Invoice" }; }
function loadStatsForm() { var s = JSON.parse(localStorage.getItem('aj_stats') || 'null') || getDefaultStats(); document.getElementById('stat1_num').value = s.s1_num; document.getElementById('stat1_label').value = s.s1_label; document.getElementById('stat2_num').value = s.s2_num; document.getElementById('stat2_label').value = s.s2_label; document.getElementById('stat3_num').value = s.s3_num; document.getElementById('stat3_label').value = s.s3_label; document.getElementById('stat4_num').value = s.s4_num; document.getElementById('stat4_label').value = s.s4_label; document.getElementById('stat5_num').value = s.s5_num; document.getElementById('stat5_label').value = s.s5_label; document.getElementById('stat6_num').value = s.s6_num; document.getElementById('stat6_label').value = s.s6_label; }
function saveStats() { var s = { s1_num: document.getElementById('stat1_num').value.trim() || '5000+', s1_label: document.getElementById('stat1_label').value.trim() || 'B2B Clients', s2_num: document.getElementById('stat2_num').value.trim() || '24-48 Hours', s2_label: document.getElementById('stat2_label').value.trim() || 'Delivery Time', s3_num: document.getElementById('stat3_num').value.trim() || '10+ Years', s3_label: document.getElementById('stat3_label').value.trim() || 'Experience', s4_num: document.getElementById('stat4_num').value.trim() || 'Same Day', s4_label: document.getElementById('stat4_label').value.trim() || 'Dispatch', s5_num: document.getElementById('stat5_num').value.trim() || 'PAN India', s5_label: document.getElementById('stat5_label').value.trim() || 'Delivery', s6_num: document.getElementById('stat6_num').value.trim() || '100%', s6_label: document.getElementById('stat6_label').value.trim() || 'GST Invoice' }; localStorage.setItem('aj_stats', JSON.stringify(s)); alert('Stats Saved - 5000+ etc. - Number + Label dono editable - All pages pe reflect - SEO Ready'); }
function getDefaultTestimonials() { return [{ name: "Rahul Sharma", company: "Delhi - E-commerce Seller", review: "Best wholesaler in Faridabad - Same day dispatch, best quality bubble wrap, genuine wholesale rates. 5000+ B2B clients trust karte hain, reason samajh aaya - Quality top notch, delivery fast, GST invoice proper.", img: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&q=80" }, { name: "Priya Enterprises - Gurgaon", company: "Gurgaon - Amazon Seller", review: "Quality top notch - GSM verified, width checked, bubble quality best. 0.5% return rate ki wajah samajh aayi - Strict quality checking before warehousing. Replacement guarantee bhi hai. Best wholesaler for e-commerce sellers.", img: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=200&q=80" }, { name: "Amit Trading Co. - Mumbai", company: "Mumbai - Wholesaler", review: "PAN India delivery - 2 days me Mumbai delivery, tracking ID same day. Bulk order 100 rolls ka tha, same day dispatch from Faridabad godown. GST invoice proper. 10+ years experience ka fayda - Factory se direct bulk purchase, best rates.", img: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=200&q=80" }]; }
var currentTestimonials = [];
function renderTestimonialEdit() { var s = localStorage.getItem('aj_testimonials'); currentTestimonials = s ? JSON.parse(s) : getDefaultTestimonials(); document.getElementById('testimonialEditGrid').innerHTML = currentTestimonials.map(function (it, i) { return '<div class="bg-[#0B1325] border border-slate-800 p-2 rounded-xl"><div class="w-12 h-12 bg-slate-950 rounded-full overflow-hidden mb-1">' + (it.img ? '<img src="' + it.img + '" class="w-full h-full object-cover">' : 'No Image') + '</div><label class="text-[9px] text-slate-400">Client Name:</label><input id="test_name_' + i + '" value="' + it.name.replace(/"/g, '&quot;') + '" class="w-full bg-slate-950 border border-slate-700 p-1 rounded text-[10px] mb-1"><label class="text-[9px] text-slate-400">Company + Location:</label><input id="test_company_' + i + '" value="' + it.company.replace(/"/g, '&quot;') + '" class="w-full bg-slate-950 border border-slate-700 p-1 rounded text-[10px] mb-1"><label class="text-[9px] text-slate-400">Review:</label><textarea id="test_review_' + i + '" rows="3" class="w-full bg-slate-950 border border-slate-700 p-1 rounded text-[10px]">' + it.review + '</textarea><label class="text-[9px] text-slate-400">Image URL:</label><input id="test_img_' + i + '" value="' + (it.img.startsWith('data:') ? '' : it.img) + '" placeholder="https://..." class="w-full mt-1 bg-slate-950 border border-slate-700 p-1 rounded text-[10px]"><input type="file" accept="image/*" onchange="upTest(this,' + i + ')" class="w-full mt-1 text-[8px]"><div class="flex gap-1 mt-1"><button onclick="saveTestItem(' + i + ')" class="flex-1 bg-[#D4AF37] text-black text-[9px] py-1 rounded font-bold">Save Client</button><button onclick="delTest(' + i + ')" class="bg-red-900 text-[9px] px-2 py-1 rounded">Delete</button></div></div>'; }).join(''); }
function addTestimonial() { currentTestimonials.push({ name: "New Client - Enter name", company: "Company - Location", review: "Enter detailed review - How was quality, delivery, rates, GST invoice etc. - Best system", img: "" }); renderTestimonialEdit(); saveTestimonials(false); }
function delTest(i) { if (!confirm('Delete this testimonial?'))
    return; currentTestimonials.splice(i, 1); renderTestimonialEdit(); saveTestimonials(false); }
async function upTest(inp, i) { var f = inp.files && inp.files[0]; if (!f)
    return; if (!validImageFile(f))
    return; var r = new FileReader(); r.onload = async function (e) { try {
    currentTestimonials[i].img = await AJShared.uploadDataUrl(e.target.result);
    renderTestimonialEdit();
    saveTestimonials(false);
    await AJShared.push();
}
catch (err) {
    console.error(err);
    alert('Testimonial image upload failed.');
} }; r.readAsDataURL(f); }
function saveTestItem(i) { var n = document.getElementById('test_name_' + i); var c = document.getElementById('test_company_' + i); var rev = document.getElementById('test_review_' + i); var img = document.getElementById('test_img_' + i); if (n)
    currentTestimonials[i].name = n.value.trim() || 'Client Name'; if (c)
    currentTestimonials[i].company = c.value.trim() || 'Company'; if (rev)
    currentTestimonials[i].review = rev.value.trim() || 'Great service'; if (img && img.value.trim())
    currentTestimonials[i].img = img.value.trim(); saveTestimonials(false); }
function saveTestimonials(show = true) { var upd = []; for (var i = 0; i < currentTestimonials.length; i++) {
    var n = document.getElementById('test_name_' + i);
    var c = document.getElementById('test_company_' + i);
    var rev = document.getElementById('test_review_' + i);
    var imgEl = document.getElementById('test_img_' + i);
    var name = n ? n.value.trim() : currentTestimonials[i].name;
    var company = c ? c.value.trim() : currentTestimonials[i].company;
    var review = rev ? rev.value.trim() : currentTestimonials[i].review;
    var img = currentTestimonials[i].img;
    if (imgEl && imgEl.value.trim())
        img = imgEl.value.trim();
    if (name)
        upd.push({ name: name, company: company, review: review, img: img });
} currentTestimonials = upd; localStorage.setItem('aj_testimonials', JSON.stringify(currentTestimonials)); if (show)
    alert('Testimonials Saved - ' + currentTestimonials.length + ' testimonials - Client images, names, companies, reviews updated - Clients page + Home preview update'); renderTestimonialEdit(); }
function clearTestimonials() { if (confirm('Clear all testimonials? Confirm?')) {
    localStorage.removeItem('aj_testimonials');
    renderTestimonialEdit();
} }
function getDefaultBlogs() { return [{ title: "How to Choose Right GSM Bubble Wrap? 40 GSM vs 80 GSM vs 120 GSM", content: "For mobile, electronics use 40-50 GSM light bubble wrap. For e-commerce packaging use 50-80 GSM standard. For furniture, heavy items use 80-120 GSM heavy bubble wrap. Small bubble 10mm for small items, large bubble 20mm for large items. 0.5m width for small, 1.0m standard best seller, 1.2m large, 1.5m jumbo. Always check GSM, width, length before buying. A.J TRADERS provides all GSM with quality checking - 0.5% return rate.", img: "https://images.unsplash.com/photo-1586528116311-ad8dd3c8310d?w=600&q=80", date: "2024-01-15" }, { title: "5 Packing Tips to Reduce Courier Damage - Save Money on Returns", content: "1. Use double layer bubble wrap for fragile items - Mobile, electronics, glass items. 2. Fill empty space with bubble wrap or air pillows - Avoid movement in box. 3. Use strong BOPP tapes - H pattern taping for boxes. 4. Use corrugated boxes with proper size - Not too big, not too small. 5. Mention Fragile sticker for courier. Follow these tips to reduce courier damage and save money on returns. A.J TRADERS provides complete packaging solutions at wholesale rates.", img: "https://images.unsplash.com/photo-1553413077-190dd305871c?w=600&q=80", date: "2024-02-10" }, { title: "Why Buy From Wholesaler Like A.J TRADERS Instead of Factory? Benefits", content: "Factories have high MOQ 50-100 rolls and waiting time 3-5 days for manufacturing. Wholesaler like A.J TRADERS gives you from 1 roll, same day dispatch, PAN India delivery in 1-3 days, GST invoice, quality checked, replacement guarantee, and best wholesale rates. 5000+ B2B clients trust us for same day dispatch and low MOQ. We buy in huge bulk from factories (10,000+ rolls), so you get factory rates without factory MOQ. Ready stock in Faridabad godown.", img: "https://images.unsplash.com/photo-1605745341112-85968b19335b?w=600&q=80", date: "2024-03-05" }]; }
var currentBlogs = [];
function renderBlogEdit() { var s = localStorage.getItem('aj_blogs'); currentBlogs = s ? JSON.parse(s) : getDefaultBlogs(); document.getElementById('blogEditList').innerHTML = currentBlogs.map(function (it, i) { return '<div class="bg-[#0B1325] border border-slate-800 p-2 rounded-xl"><div class="flex justify-between items-center"><span class="text-[10px] font-bold text-[#D4AF37]">Blog ' + (i + 1) + ' - Title + Content + Image + Date Editable</span><button onclick="delBlog(' + i + ')" class="bg-red-900 text-[9px] px-2 py-1 rounded">Delete Blog</button></div><label class="text-[9px] text-slate-400 mt-2 block">Title:</label><input id="blog_title_' + i + '" value="' + it.title.replace(/"/g, '&quot;') + '" class="w-full mt-1 bg-slate-950 border border-slate-700 p-1 rounded text-xs"><label class="text-[9px] text-slate-400 mt-1 block">Content:</label><textarea id="blog_content_' + i + '" rows="4" class="w-full mt-1 bg-slate-950 border border-slate-700 p-1 rounded text-xs">' + it.content + '</textarea><div class="grid grid-cols-2 gap-1 mt-1"><div><label class="text-[9px] text-slate-400">Image URL:</label><input id="blog_img_' + i + '" value="' + (it.img.startsWith('data:') ? '' : it.img) + '" placeholder="https://..." class="w-full bg-slate-950 border border-slate-700 p-1 rounded text-[10px]"></div><div><label class="text-[9px] text-slate-400">Date:</label><input id="blog_date_' + i + '" value="' + it.date + '" type="date" class="w-full bg-slate-950 border border-slate-700 p-1 rounded text-[10px]"></div></div><input type="file" accept="image/*" onchange="upBlog(this,' + i + ')" class="w-full mt-1 text-[8px]"><button onclick="saveBlogItem(' + i + ')" class="mt-1 bg-[#D4AF37] text-black text-[9px] px-2 py-1 rounded font-bold">Save Blog</button></div>'; }).join(''); }
function addBlog() { currentBlogs.push({ title: "New Blog - Enter title - SEO optimized", content: "Enter detailed blog content - Packing tips, GSM guide, wholesale benefits etc. - SEO optimized for Google top rank", img: "", date: new Date().toISOString().split('T')[0] }); renderBlogEdit(); saveBlogs(false); }
function delBlog(i) { if (!confirm('Delete this blog?'))
    return; currentBlogs.splice(i, 1); renderBlogEdit(); saveBlogs(false); }
async function upBlog(inp, i) { var f = inp.files && inp.files[0]; if (!f)
    return; if (!validImageFile(f))
    return; var r = new FileReader(); r.onload = async function (e) { try {
    currentBlogs[i].img = await AJShared.uploadDataUrl(e.target.result);
    renderBlogEdit();
    saveBlogs(false);
    await AJShared.push();
}
catch (err) {
    console.error(err);
    alert('Blog image upload failed.');
} }; r.readAsDataURL(f); }
function saveBlogItem(i) { var t = document.getElementById('blog_title_' + i); var c = document.getElementById('blog_content_' + i); var img = document.getElementById('blog_img_' + i); var d = document.getElementById('blog_date_' + i); if (t)
    currentBlogs[i].title = t.value.trim() || 'Blog Title'; if (c)
    currentBlogs[i].content = c.value.trim() || 'Blog Content'; if (img && img.value.trim())
    currentBlogs[i].img = img.value.trim(); if (d)
    currentBlogs[i].date = d.value; saveBlogs(false); }
function saveBlogs(show = true) { var upd = []; for (var i = 0; i < currentBlogs.length; i++) {
    var t = document.getElementById('blog_title_' + i);
    var c = document.getElementById('blog_content_' + i);
    var imgEl = document.getElementById('blog_img_' + i);
    var d = document.getElementById('blog_date_' + i);
    var title = t ? t.value.trim() : currentBlogs[i].title;
    var content = c ? c.value.trim() : currentBlogs[i].content;
    var img = currentBlogs[i].img;
    if (imgEl && imgEl.value.trim())
        img = imgEl.value.trim();
    var date = d ? d.value.trim() : currentBlogs[i].date;
    if (title)
        upd.push({ title: title, content: content, img: img, date: date });
} currentBlogs = upd; localStorage.setItem('aj_blogs', JSON.stringify(currentBlogs)); if (show)
    alert('Blogs Saved - ' + currentBlogs.length + ' blogs - Blog page + Home preview update - SEO Ready'); renderBlogEdit(); }
function clearBlogs() { if (confirm('Clear all blogs? Confirm?')) {
    localStorage.removeItem('aj_blogs');
    renderBlogEdit();
} }
function getDefaultServices() { return [{ icon: "fa-boxes-stacked", title: "Bubble Wrap Rolls Wholesale", desc: "0.5m to 1.5m small & large bubble, all GSM (40-120 GSM) in ready stock. Same day dispatch from Faridabad godown. Low MOQ from 1 roll to 1000+ rolls.", img: "https://images.unsplash.com/photo-1586528116311-ad8dd3c8310d?w=600&q=80" }, { icon: "fa-tape", title: "BOPP Tapes & Packaging Tapes Wholesale", desc: "All sizes BOPP tapes (1 inch to 3 inch) at wholesale rates. Strong adhesion, transparent & brown tapes.", img: "https://images.unsplash.com/photo-1605745341112-85968b19335b?w=600&q=80" }, { icon: "fa-box-open", title: "Corrugated Boxes & Cartons Wholesale", desc: "All sizes corrugated boxes (3 ply, 5 ply) for e-commerce, Amazon, Flipkart sellers. Custom sizes available.", img: "https://images.unsplash.com/photo-1553413077-190dd305871c?w=600&q=80" }, { icon: "fa-film", title: "Stretch Film & Wrapping Film Wholesale", desc: "Stretch wrap film (15 micron to 30 micron) for pallet wrapping, industrial use. Best wholesale prices.", img: "https://images.unsplash.com/photo-1586528116311-ad8dd3c8310d?w=600&q=80" }, { icon: "fa-bag-shopping", title: "Courier Bags & E-commerce Bags Wholesale", desc: "POD courier bags, tamper proof bags, e-commerce poly bags at wholesale rates. All sizes available.", img: "https://images.unsplash.com/photo-1605733513597-a8f8341084e1?w=600&q=80" }, { icon: "fa-truck-ramp-box", title: "Bulk Supply & PAN India Delivery Service", desc: "From 1 roll to 1000+ rolls bulk supply. Same day dispatch, 1-3 days courier, 2-5 days transport PAN India.", img: "https://images.unsplash.com/photo-1586528116311-ad8dd3c8310d?w=600&q=80" }]; }
function getDefaultWhy() { return [{ icon: "fa-handshake", title: "We Are Wholesaler, Not Factory - Factory Rates Without MOQ", desc: "We buy in huge bulk from factories, so you get factory rates without factory MOQ (50-100 rolls) & waiting time (3-5 days). Our MOQ is just 1 roll." }, { icon: "fa-clock", title: "Same Day Dispatch - Order Before 2 PM", desc: "Ready stock in Faridabad godown - 0.5m to 1.5m all sizes, all GSM. Order before 2 PM, dispatch same day with tracking ID." }, { icon: "fa-indian-rupee-sign", title: "Genuine Wholesale Rates - Low MOQ From 1 Roll", desc: "No middle man. Direct factory purchase in bulk = best wholesale rates for you. Low MOQ from 1 roll to 1000+ rolls." }, { icon: "fa-certificate", title: "Quality Checked - GSM Verified - Replacement Guarantee", desc: "Each roll checked for GSM (40-120 GSM), width (0.5m to 1.5m), bubble quality, length (100m) before warehousing." }, { icon: "fa-map-location-dot", title: "PAN India Delivery - 5000+ B2B Clients Trusted", desc: "Courier 1-3 days, Transport 2-5 days. We supply to 5000+ B2B clients across India - Delhi, Gurgaon, Noida, Mumbai, Bangalore." }, { icon: "fa-file-invoice", title: "GST Invoice & 24x7 Support - Call 9999055398", desc: "Proper GST invoice for all orders. Call/WhatsApp support on 9999055398 - Mon-Sat 9AM to 8PM. Same day rate quotes within 30 minutes." }]; }
function getDefaultProcess() { return [{ step: 1, title: "Send Inquiry Via Call, WhatsApp, or Contact Form", desc: "Tell us your requirement - Size, GSM, Quantity, Delivery Location. Call +91 9999055398 or WhatsApp or fill contact form." }, { step: 2, title: "Get Best Wholesale Rate in 30 Minutes", desc: "We give you best wholesale rate within 30 minutes based on quantity, size, GSM, delivery location." }, { step: 3, title: "Confirm Order & Make Advance Payment", desc: "Confirm your order, make advance payment via UPI, Bank Transfer, Cash. We provide GST invoice." }, { step: 4, title: "Same Day Dispatch & Fast Delivery PAN India", desc: "We dispatch same day from Faridabad godown with tracking ID shared on WhatsApp. Courier 1-3 days, transport 2-5 days PAN India." }]; }
var currentServices = [], currentWhy = [], currentProcess = [];
function renderServicesEdit() { var s = localStorage.getItem('aj_services'); currentServices = s ? JSON.parse(s) : getDefaultServices(); var w = localStorage.getItem('aj_whychoose'); currentWhy = w ? JSON.parse(w) : getDefaultWhy(); var p = localStorage.getItem('aj_process'); currentProcess = p ? JSON.parse(p) : getDefaultProcess(); document.getElementById('servicesEditGrid').innerHTML = currentServices.map(function (it, i) { return '<div class="bg-[#0B1325] border border-slate-800 p-2 rounded-xl"><div class="flex justify-between items-center"><span class="text-[10px] font-bold">Service ' + (i + 1) + '</span><button onclick="delService(' + i + ')" class="bg-red-900 text-[8px] px-2 py-1 rounded">Delete</button></div><label class="text-[9px] text-slate-400 mt-1 block">Icon (fa-...):</label><input id="serv_icon_' + i + '" value="' + it.icon + '" placeholder="fa-boxes-stacked" class="w-full mt-1 bg-slate-950 border border-slate-700 p-1 rounded text-[10px]"><label class="text-[9px] text-slate-400 mt-1 block">Title:</label><input id="serv_title_' + i + '" value="' + it.title.replace(/"/g, '&quot;') + '" class="w-full mt-1 bg-slate-950 border border-slate-700 p-1 rounded text-[10px]"><label class="text-[9px] text-slate-400 mt-1 block">Description:</label><textarea id="serv_desc_' + i + '" rows="3" class="w-full mt-1 bg-slate-950 border border-slate-700 p-1 rounded text-[10px]">' + it.desc + '</textarea><label class="text-[9px] text-slate-400 mt-1 block">Image URL:</label><input id="serv_img_' + i + '" value="' + (it.img.startsWith('data:') ? '' : it.img) + '" placeholder="https://..." class="w-full mt-1 bg-slate-950 border border-slate-700 p-1 rounded text-[10px]"><input type="file" accept="image/*" onchange="upServ(this,' + i + ')" class="w-full mt-1 text-[8px]"><button onclick="saveServItem(' + i + ')" class="mt-1 bg-[#D4AF37] text-black text-[9px] px-2 py-1 rounded font-bold">Save Service</button></div>'; }).join(''); document.getElementById('whyEditGrid').innerHTML = currentWhy.map(function (it, i) { return '<div class="bg-[#0B1325] border border-slate-800 p-2 rounded-xl"><div class="flex justify-between items-center"><span class="text-[10px] font-bold">Why ' + (i + 1) + '</span><button onclick="delWhyItem(' + i + ')" class="bg-red-900 text-[8px] px-2 py-1 rounded">Delete</button></div><label class="text-[9px] text-slate-400 mt-1 block">Icon:</label><input id="why_icon_' + i + '" value="' + it.icon + '" class="w-full mt-1 bg-slate-950 border border-slate-700 p-1 rounded text-[10px]"><label class="text-[9px] text-slate-400 mt-1 block">Title:</label><input id="why_title_' + i + '" value="' + it.title.replace(/"/g, '&quot;') + '" class="w-full mt-1 bg-slate-950 border border-slate-700 p-1 rounded text-[10px]"><label class="text-[9px] text-slate-400 mt-1 block">Description:</label><textarea id="why_desc_' + i + '" rows="3" class="w-full mt-1 bg-slate-950 border border-slate-700 p-1 rounded text-[10px]">' + it.desc + '</textarea><button onclick="saveWhyItem(' + i + ')" class="mt-1 bg-[#D4AF37] text-black text-[9px] px-2 py-1 rounded font-bold">Save Why</button></div>'; }).join(''); document.getElementById('processEditGrid').innerHTML = currentProcess.map(function (it, i) { return '<div class="bg-[#0B1325] border border-slate-800 p-2 rounded-xl"><div class="flex justify-between items-center"><span class="text-[10px] font-bold">Step ' + it.step + '</span><button onclick="delProcess(' + i + ')" class="bg-red-900 text-[8px] px-2 py-1 rounded">Delete</button></div><label class="text-[9px] text-slate-400 mt-1 block">Title:</label><input id="proc_title_' + i + '" value="' + it.title.replace(/"/g, '&quot;') + '" class="w-full mt-1 bg-slate-950 border border-slate-700 p-1 rounded text-[10px]"><label class="text-[9px] text-slate-400 mt-1 block">Description:</label><textarea id="proc_desc_' + i + '" rows="3" class="w-full mt-1 bg-slate-950 border border-slate-700 p-1 rounded text-[10px]">' + it.desc + '</textarea><button onclick="saveProcItem(' + i + ')" class="mt-1 bg-[#D4AF37] text-black text-[9px] px-2 py-1 rounded font-bold">Save Step</button></div>'; }).join(''); }
function addService() { currentServices.push({ icon: "fa-box", title: "New Service - Enter title", desc: "Enter description - What you provide, sizes, MOQ, delivery etc.", img: "" }); renderServicesEdit(); saveServices(false); }
function delService(i) { if (!confirm('Delete this service?'))
    return; currentServices.splice(i, 1); renderServicesEdit(); saveServices(false); }
function addWhy() { currentWhy.push({ icon: "fa-star", title: "New Why Choose Us Point", desc: "Enter why clients should choose you" }); renderServicesEdit(); saveServices(false); }
function delWhyItem(i) { if (!confirm('Delete this why choose point?'))
    return; currentWhy.splice(i, 1); renderServicesEdit(); saveServices(false); }
function addProcess() { currentProcess.push({ step: currentProcess.length + 1, title: "New Process Step", desc: "Enter process description" }); renderServicesEdit(); saveServices(false); }
function delProcess(i) { if (!confirm('Delete this process step?'))
    return; currentProcess.splice(i, 1); renderServicesEdit(); saveServices(false); }
function clearServices() { if (confirm('Clear all services? Confirm?')) {
    localStorage.removeItem('aj_services');
    renderServicesEdit();
} }
function clearWhy() { if (confirm('Clear all why choose us? Confirm?')) {
    localStorage.removeItem('aj_whychoose');
    renderServicesEdit();
} }
function clearProcess() { if (confirm('Clear all process steps? Confirm?')) {
    localStorage.removeItem('aj_process');
    renderServicesEdit();
} }
async function upServ(inp, i) { var f = inp.files && inp.files[0]; if (!f)
    return; if (!validImageFile(f))
    return; var r = new FileReader(); r.onload = async function (e) { try {
    currentServices[i].img = await AJShared.uploadDataUrl(e.target.result);
    renderServicesEdit();
    saveServices(false);
    await AJShared.push();
}
catch (err) {
    console.error(err);
    alert('Service image upload failed.');
} }; r.readAsDataURL(f); }
function saveServItem(i) { var icon = document.getElementById('serv_icon_' + i); var title = document.getElementById('serv_title_' + i); var desc = document.getElementById('serv_desc_' + i); var imgEl = document.getElementById('serv_img_' + i); if (icon)
    currentServices[i].icon = icon.value.trim() || 'fa-box'; if (title)
    currentServices[i].title = title.value.trim() || 'Service'; if (desc)
    currentServices[i].desc = desc.value.trim() || 'Description'; if (imgEl && imgEl.value.trim())
    currentServices[i].img = imgEl.value.trim(); saveServices(false); }
function saveWhyItem(i) { var icon = document.getElementById('why_icon_' + i); var title = document.getElementById('why_title_' + i); var desc = document.getElementById('why_desc_' + i); if (icon)
    currentWhy[i].icon = icon.value.trim() || 'fa-star'; if (title)
    currentWhy[i].title = title.value.trim() || 'Why'; if (desc)
    currentWhy[i].desc = desc.value.trim() || 'Description'; saveServices(false); }
function saveProcItem(i) { var title = document.getElementById('proc_title_' + i); var desc = document.getElementById('proc_desc_' + i); if (title)
    currentProcess[i].title = title.value.trim() || 'Step'; if (desc)
    currentProcess[i].desc = desc.value.trim() || 'Description'; saveServices(false); }
function saveServices(show = true) { var s = [], w = [], p = []; for (var i = 0; i < currentServices.length; i++) {
    var icon = document.getElementById('serv_icon_' + i);
    var title = document.getElementById('serv_title_' + i);
    var desc = document.getElementById('serv_desc_' + i);
    var imgEl = document.getElementById('serv_img_' + i);
    var ic = icon ? icon.value.trim() : currentServices[i].icon;
    var t = title ? title.value.trim() : currentServices[i].title;
    var d = desc ? desc.value.trim() : currentServices[i].desc;
    var img = currentServices[i].img;
    if (imgEl && imgEl.value.trim())
        img = imgEl.value.trim();
    if (t)
        s.push({ icon: ic, title: t, desc: d, img: img });
} for (var i = 0; i < currentWhy.length; i++) {
    var icon = document.getElementById('why_icon_' + i);
    var title = document.getElementById('why_title_' + i);
    var desc = document.getElementById('why_desc_' + i);
    var ic = icon ? icon.value.trim() : currentWhy[i].icon;
    var t = title ? title.value.trim() : currentWhy[i].title;
    var d = desc ? desc.value.trim() : currentWhy[i].desc;
    if (t)
        w.push({ icon: ic, title: t, desc: d });
} for (var i = 0; i < currentProcess.length; i++) {
    var title = document.getElementById('proc_title_' + i);
    var desc = document.getElementById('proc_desc_' + i);
    var t = title ? title.value.trim() : currentProcess[i].title;
    var d = desc ? desc.value.trim() : currentProcess[i].desc;
    if (t)
        p.push({ step: i + 1, title: t, desc: d });
} currentServices = s; currentWhy = w; currentProcess = p; localStorage.setItem('aj_services', JSON.stringify(currentServices)); localStorage.setItem('aj_whychoose', JSON.stringify(currentWhy)); localStorage.setItem('aj_process', JSON.stringify(currentProcess)); if (show)
    alert('Services Saved - ' + currentServices.length + ' services, ' + currentWhy.length + ' why choose, ' + currentProcess.length + ' process steps - Services page update'); renderServicesEdit(); }
function getDefaultCerts() { return [{ title: "GST Certificate - Registered Wholesaler", desc: "Registered GST wholesaler - 100% GST invoice for all orders", img: "https://images.unsplash.com/photo-1589829085413-56de8ae18c73?w=600&q=80" }, { title: "MSME Registered", desc: "MSME registered wholesaler - Trusted by government & B2B clients", img: "https://images.unsplash.com/photo-1554224155-6726b3ff858f?w=600&q=80" }, { title: "Factory Authorization Letters", desc: "Direct authorization from top bubble wrap factories - Bulk purchase at factory rates", img: "https://images.unsplash.com/photo-1450101499163-c8848c66ca85?w=600&q=80" }, { title: "Quality Checking Process", desc: "GSM, width, length, bubble quality checking before warehousing", img: "https://images.unsplash.com/photo-1586528116311-ad8dd3c8310d?w=600&q=80" }, { title: "Warehouse - Faridabad Godown", desc: "Huge ready stock in Faridabad - 0.5m to 1.5m all sizes available", img: "https://images.unsplash.com/photo-1553413077-190dd305871c?w=600&q=80" }, { title: "PAN India Delivery Proof", desc: "Courier & transport delivery across India - 5000+ B2B clients", img: "https://images.unsplash.com/photo-1605745341112-85968b19335b?w=600&q=80" }]; }
function getDefaultQuality() { return [{ step: 1, icon: "fa-weight-hanging", title: "GSM Weight Checking - 40 GSM to 120 GSM Verified", desc: "Each roll weighed to verify GSM as per standard. 40 GSM to 120 GSM verified." }, { step: 2, icon: "fa-ruler-combined", title: "Width & Length Verification", desc: "0.5m to 1.5m width checked with measuring tape. 100m length confirmed." }, { step: 3, icon: "fa-eye", title: "Bubble Quality Inspection", desc: "Small bubble & large bubble size, air retention checked." }, { step: 4, icon: "fa-boxes-packing", title: "Packaging & Warehousing", desc: "After quality check, rolls properly packed and stored in Faridabad godown." }, { step: 5, icon: "fa-truck-fast", title: "Dispatch Quality Check", desc: "Before dispatch, again checked for any damage during storage." }]; }
var currentCerts = [], currentQuality = [];
function renderCertsEdit() { var c = localStorage.getItem('aj_certificates'); currentCerts = c ? JSON.parse(c) : getDefaultCerts(); var q = localStorage.getItem('aj_quality'); currentQuality = q ? JSON.parse(q) : getDefaultQuality(); document.getElementById('certsEditGrid').innerHTML = currentCerts.map(function (it, i) { return '<div class="bg-[#0B1325] border border-slate-800 p-2 rounded-xl"><div class="h-16 bg-slate-950 rounded overflow-hidden mb-1">' + (it.img ? '<img src="' + it.img + '" class="w-full h-full object-cover">' : 'No Image') + '</div><div class="flex justify-between items-center"><span class="text-[10px] font-bold">Cert ' + (i + 1) + '</span><button onclick="delCert(' + i + ')" class="bg-red-900 text-[8px] px-2 py-1 rounded">Delete</button></div><label class="text-[9px] text-slate-400 mt-1 block">Title:</label><input id="cert_title_' + i + '" value="' + it.title.replace(/"/g, '&quot;') + '" class="w-full mt-1 bg-slate-950 border border-slate-700 p-1 rounded text-[10px]"><label class="text-[9px] text-slate-400 mt-1 block">Description:</label><textarea id="cert_desc_' + i + '" rows="2" class="w-full mt-1 bg-slate-950 border border-slate-700 p-1 rounded text-[10px]">' + it.desc + '</textarea><label class="text-[9px] text-slate-400 mt-1 block">Image URL:</label><input id="cert_img_' + i + '" value="' + (it.img.startsWith('data:') ? '' : it.img) + '" placeholder="https://..." class="w-full mt-1 bg-slate-950 border border-slate-700 p-1 rounded text-[10px]"><input type="file" accept="image/*" onchange="upCert(this,' + i + ')" class="w-full mt-1 text-[8px]"><button onclick="saveCertItem(' + i + ')" class="mt-1 bg-[#D4AF37] text-black text-[9px] px-2 py-1 rounded font-bold">Save Certificate</button></div>'; }).join(''); document.getElementById('qualityEditGrid').innerHTML = currentQuality.map(function (it, i) { return '<div class="bg-[#0B1325] border border-slate-800 p-2 rounded-xl"><div class="flex justify-between items-center"><span class="text-[10px] font-bold">Quality Step ' + it.step + '</span><button onclick="delQualityItem(' + i + ')" class="bg-red-900 text-[8px] px-2 py-1 rounded">Delete</button></div><label class="text-[9px] text-slate-400 mt-1 block">Icon:</label><input id="qual_icon_' + i + '" value="' + it.icon + '" class="w-full mt-1 bg-slate-950 border border-slate-700 p-1 rounded text-[10px]"><label class="text-[9px] text-slate-400 mt-1 block">Title:</label><input id="qual_title_' + i + '" value="' + it.title.replace(/"/g, '&quot;') + '" class="w-full mt-1 bg-slate-950 border border-slate-700 p-1 rounded text-[10px]"><label class="text-[9px] text-slate-400 mt-1 block">Description:</label><textarea id="qual_desc_' + i + '" rows="2" class="w-full mt-1 bg-slate-950 border border-slate-700 p-1 rounded text-[10px]">' + it.desc + '</textarea><button onclick="saveQualItem(' + i + ')" class="mt-1 bg-[#D4AF37] text-black text-[9px] px-2 py-1 rounded font-bold">Save Quality Step</button></div>'; }).join(''); }
function addCert() { currentCerts.push({ title: "New Certificate - Enter title", desc: "Enter description - What certificate, why important etc.", img: "" }); renderCertsEdit(); saveCertificates(false); }
function delCert(i) { if (!confirm('Delete this certificate?'))
    return; currentCerts.splice(i, 1); renderCertsEdit(); saveCertificates(false); }
function addQuality() { currentQuality.push({ step: currentQuality.length + 1, icon: "fa-check", title: "New Quality Step", desc: "Enter quality checking description" }); renderCertsEdit(); saveCertificates(false); }
function delQualityItem(i) { if (!confirm('Delete this quality step?'))
    return; currentQuality.splice(i, 1); renderCertsEdit(); saveCertificates(false); }
function clearCerts() { if (confirm('Clear all certificates? Confirm?')) {
    localStorage.removeItem('aj_certificates');
    renderCertsEdit();
} }
function clearQuality() { if (confirm('Clear all quality steps? Confirm?')) {
    localStorage.removeItem('aj_quality');
    renderCertsEdit();
} }
async function upCert(inp, i) { var f = inp.files && inp.files[0]; if (!f)
    return; if (!validImageFile(f))
    return; var r = new FileReader(); r.onload = async function (e) { try {
    currentCerts[i].img = await AJShared.uploadDataUrl(e.target.result);
    renderCertsEdit();
    saveCertificates(false);
    await AJShared.push();
}
catch (err) {
    console.error(err);
    alert('Certificate image upload failed.');
} }; r.readAsDataURL(f); }
function saveCertItem(i) { var t = document.getElementById('cert_title_' + i); var d = document.getElementById('cert_desc_' + i); var imgEl = document.getElementById('cert_img_' + i); if (t)
    currentCerts[i].title = t.value.trim() || 'Certificate'; if (d)
    currentCerts[i].desc = d.value.trim() || 'Description'; if (imgEl && imgEl.value.trim())
    currentCerts[i].img = imgEl.value.trim(); saveCertificates(false); }
function saveQualItem(i) { var icon = document.getElementById('qual_icon_' + i); var title = document.getElementById('qual_title_' + i); var desc = document.getElementById('qual_desc_' + i); if (icon)
    currentQuality[i].icon = icon.value.trim() || 'fa-check'; if (title)
    currentQuality[i].title = title.value.trim() || 'Quality Step'; if (desc)
    currentQuality[i].desc = desc.value.trim() || 'Description'; saveCertificates(false); }
function saveCertificates(show = true) { var c = [], q = []; for (var i = 0; i < currentCerts.length; i++) {
    var t = document.getElementById('cert_title_' + i);
    var d = document.getElementById('cert_desc_' + i);
    var imgEl = document.getElementById('cert_img_' + i);
    var title = t ? t.value.trim() : currentCerts[i].title;
    var desc = d ? d.value.trim() : currentCerts[i].desc;
    var img = currentCerts[i].img;
    if (imgEl && imgEl.value.trim())
        img = imgEl.value.trim();
    if (title)
        c.push({ title: title, desc: desc, img: img });
} for (var i = 0; i < currentQuality.length; i++) {
    var icon = document.getElementById('qual_icon_' + i);
    var title = document.getElementById('qual_title_' + i);
    var desc = document.getElementById('qual_desc_' + i);
    var ic = icon ? icon.value.trim() : currentQuality[i].icon;
    var t = title ? title.value.trim() : currentQuality[i].title;
    var d = desc ? desc.value.trim() : currentQuality[i].desc;
    if (t)
        q.push({ step: i + 1, icon: ic, title: t, desc: d });
} currentCerts = c; currentQuality = q; localStorage.setItem('aj_certificates', JSON.stringify(currentCerts)); localStorage.setItem('aj_quality', JSON.stringify(currentQuality)); if (show)
    alert('Certificates Saved - ' + currentCerts.length + ' certificates, ' + currentQuality.length + ' quality steps - Certificates page update'); renderCertsEdit(); }
async function readImageToField(input, fieldId, key) { var f = input.files && input.files[0]; if (!f)
    return; if (!validImageFile(f)) {
    input.value = '';
    return;
} if (!window.AJShared || !AJShared.uploadDataUrl) {
    alert('Image service not ready. Please wait 2 seconds and try again.');
    return;
} var r = new FileReader(); r.onload = async function (e) { try {
    var url = await AJShared.uploadDataUrl(e.target.result);
    var c = JSON.parse(localStorage.getItem('aj_content') || '{}');
    c[key] = url;
    localStorage.setItem('aj_content', JSON.stringify(c));
    document.getElementById(fieldId).value = '';
    renderHero();
    renderProd();
    await AJShared.push();
    alert('Image updated globally.');
}
catch (err) {
    console.error(err);
    alert('Image upload failed. Please check Supabase Storage/SQL.');
} }; r.readAsDataURL(f); }
document.getElementById('cPhotoFile').addEventListener('change', function () { readImageToField(this, 'cPhoto', 'ceoPhoto'); });
document.getElementById('logoFile').addEventListener('change', function () { readImageToField(this, 'logoUrl', 'logo'); });
function saveSupabaseUrl() { alert('Supabase connection is already configured for this website.'); }
function loadAll() { var su = document.getElementById('supabaseUrl'); if (su)
    su.value = 'https://bijohvnrjwcgwpypebcd.supabase.co'; loadLeads(); loadContentForm(); renderHero(); renderProd(); renderFaqEdit(); renderGalleryEdit(); loadStatsForm(); renderTestimonialEdit(); renderBlogEdit(); renderServicesEdit(); renderCertsEdit(); }
